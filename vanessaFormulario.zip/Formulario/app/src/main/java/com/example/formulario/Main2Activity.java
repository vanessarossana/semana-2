package com.example.formulario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    private TextView txt2, txt3, txt4, txt5, txt6;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        txt2 = (TextView)findViewById(R.id.txt2);
        txt3 = (TextView)findViewById(R.id.txt3);
        txt4 = (TextView)findViewById(R.id.txt4);
        txt5 = (TextView)findViewById(R.id.txt5);
        txt6 = (TextView)findViewById(R.id.txt6);
        button = (Button)findViewById(R.id.button);


        Bundle parametros = getIntent().getExtras();

        String nombre = parametros.getString("nombre");
        String correo = parametros.getString("correo");
        String telefono = parametros.getString("telefono");
        String descripcion = parametros.getString("descripcion");
        String mDisplayDate = parametros.getString("date");

        txt2.setText("nombre: " + nombre);
        txt3.setText("Fecha: " + mDisplayDate);
        txt4.setText("Tel: " + telefono);
        txt5.setText("correo: " + correo);
        txt6.setText("descripcion: " + descripcion);
    }


    public void Regresar(View view){
        Intent Regresar = new Intent(this, MainActivity.class);
        startActivity(Regresar);

    }
}
